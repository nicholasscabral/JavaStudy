import java.util.ArrayList;
import java.util.Scanner;

public class hotel {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int escolha, acompanhantes, diasDeEstadia;
        String responsavel;
        ArrayList<quartos> ListaQuartos = new ArrayList<>();
        ArrayList<pacotes> ListaPacotes = new ArrayList<>();

        //cadastrando quartos
        quartos quarto1 = new quartos(2, 5);
        ListaQuartos.add(quarto1);
        quartos quarto2 = new quartos(1, 2);
        ListaQuartos.add(quarto2);
        quartos quarto3 = new quartos(3, 6);
        ListaQuartos.add(quarto3);

        //casdtrar pacotes
        pacotes pacote1 = new pacotes("Mestre", 1500);
        ListaPacotes.add(pacote1);
        pacotes pacote2 = new pacotes("solteiro", 400);
        ListaPacotes.add(pacote2);

        System.out.println("Oque deseja fazer? \n" +
                "1- Check-in \n" +
                "2- opções de quartos \n" +
                "3- opções de pacotes");
        escolha = input.nextInt();
        if (escolha == 1) {
            System.out.println("nome do responsavel");
            responsavel = input.next();
            System.out.println("numero de acompanhantes");
            acompanhantes = input.nextInt();
            System.out.println("dias de estadia");
            diasDeEstadia = input.nextInt();
            hospedes familia = new hospedes(responsavel, acompanhantes, diasDeEstadia);
            System.out.println("1 familia cadastrada \n" + familia);
        }
        else if (escolha == 2) {
            for (quartos i : ListaQuartos) {
                System.out.println(i);
            }
        }
        else if (escolha == 3) {
            for (pacotes i : ListaPacotes) {
                System.out.println(i);
            }
        }
    }
}
