import java.util.ArrayList;
import java.util.Scanner;

public class inclusos {
    ArrayList<String> inclusos = new ArrayList<>();
    int NumeroDeInclusos;
    Scanner input = new Scanner(System.in);

    public ArrayList CadastrarInslusos() {
        System.out.println("Quantos beneficios ha nesse pacote?");
        NumeroDeInclusos = input.nextInt();
        inclusos.clear();

        for (int i = 0; i < NumeroDeInclusos; i++) {
            System.out.println((i+1) + "º incluso");
            String incluso = input.next();
            inclusos.add(incluso);
        }

        return inclusos;
    }
}
