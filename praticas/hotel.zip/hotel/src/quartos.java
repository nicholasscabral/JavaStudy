public class quartos {
    int camas, capacidade;

    public quartos(int camas, int capacidade) {
        this.camas = camas;
        this.capacidade = capacidade;
    }

    public int getCamas() {
        return camas;
    }

    public void setCamas(int camas) {
        this.camas = camas;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    @Override
    public String toString() {
        return "informações do quarto = {\n" +
                "   quantidade de camas: " + camas + ",\n" +
                "   capacidade: " + capacidade + "\n}";
    }
}

